import java.util.Scanner;

public class ATM {
    private BankAccount account;
    private Scanner scanner;
    private static final double MAX_WITHDRAWAL = 50000.0;
    private static final double MAX_DEPOSIT = 100000.0;
    private static final String CORRECT_PIN = "1234"; // Default PIN

    public ATM(BankAccount account) {
        this.account = account;
        this.scanner = new Scanner(System.in);
    }

    public void start() {
        System.out.println("========================================");
        System.out.println("         WELCOME TO CODSOFT ATM        ");
        System.out.println("========================================");

        if (!authenticateUser()) {
            System.out.println("Too many incorrect attempts. Card blocked.");
            System.out.println("Please contact your bank. Goodbye!");
            return;
        }

        System.out.println("\nWelcome, " + account.getAccountHolder() + "!");
        System.out.println("Account: " + account.getMaskedAccountNumber());

        boolean running = true;
        while (running) {
            showMenu();
            System.out.print("Enter your choice: ");
            String input = scanner.nextLine().trim();

            switch (input) {
                case "1": checkBalance(); break;
                case "2": deposit(); break;
                case "3": withdraw(); break;
                case "4": running = false; break;
                default:
                    System.out.println("\n⚠ Invalid choice! Please select 1-4.");
            }
        }

        System.out.println("\n========================================");
        System.out.println("   Thank you for using CODSOFT ATM!    ");
        System.out.println("     Please collect your card.         ");
        System.out.println("========================================");
    }

    private boolean authenticateUser() {
        int maxAttempts = 3;
        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            System.out.print("Enter your PIN: ");
            String pin = scanner.nextLine().trim();

            if (pin.equals(CORRECT_PIN)) {
                System.out.println("✔ PIN verified successfully!");
                return true;
            } else {
                int remaining = maxAttempts - attempt;
                if (remaining > 0) {
                    System.out.println("❌ Incorrect PIN! " + remaining + " attempt(s) remaining.");
                }
            }
        }
        return false;
    }

    private void showMenu() {
        System.out.println("\n========================================");
        System.out.println("              ATM MENU                  ");
        System.out.println("========================================");
        System.out.println("  1. Check Balance");
        System.out.println("  2. Deposit Money");
        System.out.println("  3. Withdraw Money");
        System.out.println("  4. Exit");
        System.out.println("========================================");
    }

    private void checkBalance() {
        System.out.println("\n----------------------------------------");
        System.out.println("         ACCOUNT BALANCE                ");
        System.out.println("----------------------------------------");
        System.out.printf("  Available Balance: Rs. %.2f%n", account.getBalance());
        System.out.println("----------------------------------------");
    }

    private void deposit() {
        System.out.println("\n--- DEPOSIT ---");
        System.out.print("Enter amount to deposit (Max Rs. " + MAX_DEPOSIT + "): Rs. ");

        double amount;
        try {
            amount = Double.parseDouble(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("❌ Invalid amount entered!");
            return;
        }

        if (amount <= 0) {
            System.out.println("❌ Amount must be greater than zero.");
            return;
        }
        if (amount > MAX_DEPOSIT) {
            System.out.println("❌ Amount exceeds maximum deposit limit of Rs. " + MAX_DEPOSIT);
            return;
        }

        if (account.deposit(amount)) {
            System.out.printf("✔ Rs. %.2f deposited successfully!%n", amount);
            System.out.printf("  New Balance: Rs. %.2f%n", account.getBalance());
        } else {
            System.out.println("❌ Deposit failed. Please try again.");
        }
    }

    private void withdraw() {
        System.out.println("\n--- WITHDRAWAL ---");
        System.out.printf("  Available Balance: Rs. %.2f%n", account.getBalance());
        System.out.print("Enter amount to withdraw (Max Rs. " + MAX_WITHDRAWAL + "): Rs. ");

        double amount;
        try {
            amount = Double.parseDouble(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("❌ Invalid amount entered!");
            return;
        }

        if (amount <= 0) {
            System.out.println("❌ Amount must be greater than zero.");
            return;
        }
        if (amount > MAX_WITHDRAWAL) {
            System.out.println("❌ Amount exceeds maximum withdrawal limit of Rs. " + MAX_WITHDRAWAL);
            return;
        }
        if (amount > account.getBalance()) {
            System.out.println("❌ Insufficient balance!");
            System.out.printf("  Available Balance: Rs. %.2f%n", account.getBalance());
            return;
        }

        if (account.withdraw(amount)) {
            System.out.printf("✔ Rs. %.2f withdrawn successfully!%n", amount);
            System.out.printf("  Remaining Balance: Rs. %.2f%n", account.getBalance());
            System.out.println("  Please collect your cash.");
        } else {
            System.out.println("❌ Withdrawal failed. Please try again.");
        }
    }
}
